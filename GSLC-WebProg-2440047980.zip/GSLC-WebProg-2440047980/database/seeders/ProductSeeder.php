<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::query()->insert(
            [
                [
                    "id" => 1,
                    "name" => "Naruto Shippuden",
                    "type" => "Action",
                    "desc" => "Seri anime yang diadaptasi dari bagian II manga Naruto.",
                    "episode" => "TV (500 Episode)",
                    "image_path" => "https://cdn.myanimelist.net/images/anime/5/17407.jpg"
                ],
                [
                    "id" => 2,
                    "name" => "Beast Tamer",
                    "type" => "Action",
                    "desc" => "Seri novel ringan Jepang yang ditulis oleh Suzu Miyama.",
                    "episode" => "TV (6+ Episode)",
                    "image_path" => "https://i0.wp.com/animasu.live/wp-content/uploads/2022/10/126652.jpg"
                ],
                [
                    "id" => 3,
                    "name" => "Cyberpunk : Edgerunners",
                    "type" => "Sci Fi",
                    "desc" => "Anak jalanan bertahan dengan teknologi dan modifikasi tubuh di kota masa depan.",
                    "episode" => "Netflix (10 Episode x 24 Min)",
                    "image_path" => "https://i0.wp.com/animasu.live/wp-content/uploads/2022/11/126435.jpg"
                ],
                [
                    "id" => 4,
                    "name" => "Great Pretender",
                    "type" => "Comedy",
                    "desc" => "Makoto Edamura adalah seorang penipu yang dikatakan sebagai penipu terbesar Jepang.",
                    "episode" => "Web (23 Epiosde x 24 Min)",
                    "image_path" => "https://cdn.myanimelist.net/images/anime/1418/107954.jpg"
                ],
                [
                    "id" => 5,
                    "name" => "SPY X FAMILY Season 1",
                    "type" => "Comedy",
                    "desc" => "Twilight adalah mata-mata terbaik ketika harus menyamar dalam misi berbahaya.",
                    "episode" => "TV (12 Episode)",
                    "image_path" => "https://cdn.myanimelist.net/images/anime/1823/119156.jpg"
                ]
            ]
        );
    }
}
