<footer class="footer" id="contact">
    <div class="card text-center">
        <div class="card-header">
          Support Us
        </div>
        <div class="card-body">
          <h5 class="card-title">MyAnimeFavorite is run by fans, for fans</h5>
          <p class="card-text">Learn about more ways to support MyAnimeFavorite</p>
          <a href="https://bit.ly/3Ql1kMo" class="btn btn-primary">Support</a>
        </div>
        <div class="card-footer text-muted">
          2440047980-Benyamin Kristiawan Aliwinoto GSLC Web Programming
        </div>
      </div>
</footer>
