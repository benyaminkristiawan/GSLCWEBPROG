<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

    <title>@yield('title')</title>
</head>
<body>
    <nav class="navbar bg-light">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Reccomendations</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">On Going</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">Community</a>
                  </li>
                </ul>
              </div>
          <a class="navbar-brand" href="#">
            <img src="https://img.freepik.com/free-vector/cute-cat-drink-boba-milk-tea-cartoon-icon-illustration_138676-2830.jpg?w=740&t=st=1667871755~exp=1667872355~hmac=92b8c8a5aed6803b6382ab33a7141275ce0fff7994ae25f4d5225d2d09624e61" alt="Logo" width="30" height="30" class="d-inline-block align-text-top">
            MyAnimeFavorite</a>

          <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
          </form>
        </div>
      </nav>
    @yield('content')
</body>
</html>
