<?php $__env->startSection('title','home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-sm">
        <div class="container d-flex">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 18rem;">
                <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="...">
                <a href="#" class="btn btn-light">Play</a>
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($d->name); ?></h5>
                  <p class="card-text"><?php echo e($d->desc); ?></p>
                  <p class="card-text"><?php echo e($d->episode); ?></p>
                  <?php if($d->type === "Action"): ?>
                    <span class="badge text bg-danger"><?php echo e($d->type); ?></span>
                    <?php elseif($d->type === "Comedy"): ?>
                    <span class="badge text bg-primary"><?php echo e($d->type); ?></span>
                    <?php else: ?>
                    <span class="badge text bg-warning"><?php echo e($d->type); ?></span>
                  <?php endif; ?>

                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\benya\Documents\Binus Sem 5\session 2\resources\views/home.blade.php ENDPATH**/ ?>